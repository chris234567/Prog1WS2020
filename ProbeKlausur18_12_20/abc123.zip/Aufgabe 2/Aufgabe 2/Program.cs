﻿using System;

namespace Aufgabe_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Auslesen eines Log-Files");
        }
    }
}
