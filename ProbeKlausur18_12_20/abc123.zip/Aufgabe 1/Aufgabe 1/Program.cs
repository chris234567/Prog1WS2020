﻿using System;

namespace Aufgabe_1
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
